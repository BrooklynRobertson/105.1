#pragma once
#include <vector>
#include <string>
#include <iostream>

//function overloads for printing shape menu title

void shapeMenu();
void shapeMenu(int);