#pragma once
#include <vector>
#include <string>
#include <iostream>
using namespace std;

enum class Race {
	HUMAN = 1,
	ELF = 2,
	DWARF = 3,
	ORC = 4,
	TROLL = 5
}race;