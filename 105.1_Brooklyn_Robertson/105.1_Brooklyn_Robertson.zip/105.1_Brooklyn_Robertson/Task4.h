
#pragma once
#include <vector>
#include <string>
#include <iostream>

class Alien;


const void operator+(const Alien& obj);
