#pragma once
#include <vector>
#include <string>
#include <iostream>

class Yacht;
class Location;
void operator << (std::ostream&op, Location& location);